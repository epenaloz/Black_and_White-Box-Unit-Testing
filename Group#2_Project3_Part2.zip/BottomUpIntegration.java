//Enrique Penaloza      Bottom up integration on student class
public class BottomUpIntegration{
public static void main(String[] args)
{
  Student bob = new Student(“Bob”,”Smith”,12345,Student.StudentType.undergraduate, new FinancialAid(5000, true));
  Student joe = new Student(“Joseph”,”Jones”,987654,Student.StudentType.graduate, new FinancialAid(2000, false));
  Student[] myStudents = { bob, joe };

  // Add some courses to the schedule of both bob and joe here.
  // The syntax to do this would be of the form:
     bob.getSchedule().addCourse(new Course("Software Testing", "SWE", 3643, 3, 3.0, true, true) );
     bob.getSchedule().addCourse(new Course("Software Enginerring", "SWE", 4435, 4, 3.0, true, false) );
     bob.getSchedule().addCourse(new Course("Software Architecture", "SWE", 4262, 4, 3.0, false, true) );
     bob.getSchedule().addCourse(new Course("Software Development", "SWE", 3854, 3, 3.0, false, false) );
     joe.getSchedule().addCourse(new Course("Cloud computing", "CS", 4512, 3, 3.0, true, true) );
     joe.getSchedule().addCourse(new Course("Data Mining", "CS", 5743, 3, 3.0, true, false) );
     joe.getSchedule().addCourse(new Course("Computer principles 2", "CS", 3143, 4, 3.0, false, true) );
     joe.getSchedule().addCourse(new Course("Data Structures", "CS", 5001, 4, 3.0, false, false) );

  //bob.getSchedule().addCourse(new Course("Software Testing", "SWE", 3643, 1, 3.0, false, false) );
  // Be sure to choose a suitable variety and number of courses.

  // You might consider removing a course or two here to make sure that works as well.

  for (Student s : myStudents)
  {
    System.out.print( s.getFirstName + “ “ + s.getLastName + “ is “);

    if (s.getStudentType == Student.StudentType.undergraduate)
      System.out.print(“an undergraduate ”);
    else
      System.out.print(“a graduate ”);

    System.out.println(“student with ID #” + s.getID() + “.”);
    System.out.print(“The student is enrolled for “ + s.getSchedule().getHours() + “ hours and is classified as “);

    if (s.isFullTime())
      System.out.println(“ full-time.”);
    else 
      System.out.println(“ part-time.”); 

    System.out.print(“The student’s financial aid award is $“ + s.getAward().getAmount() + ” and is “);

    if ( ! s.getAward().isContingent() )
      System.out.print(“NOT “);

    System.out.println(“contingent on full-time enrollment.”);
    System.out.println(“The student’s tuition bill is $” + s.amountDue() + “.”);
    System.out.print("\n\n");
  }
}}

/*From bottom up integration, the student phase would be the first phase to implement. The student phase would pass
initalizing the student's first, last name, student ID, and studentType. It would fail to retrieve the status
whether they'll recieve financial aid or not because it depends on the schedule to retrieve the array of courses.

The second class would be FinancialAid. Financial aid would initalize the student whether he/she
would get financial aid or not. It would need the course class again to return an award wether 
they'll get the award (true) or not (stay as false).

The third phase is the Bill method. The bill would return a price of $0 tunition because without
the course having an array of courses, there is nothing to calculate but calculate NULL. The
bill class would however create a bill for the student, but with no fee.

The fourth phase is Schedule. There would be an error when adding or removing a course because there
wouldn't be no catalog to pickout the course number, whther it would be online or not.
However, clearing a schedule with the cleas schedule method would function but it would
clear an already clear function. The constructor would also create a schedule with aero courses.
Gethours would work without courses.

The root of the description is the course class. The course class determines which student,
what class name, what course number, and what courses do they choose to add on the schedule class,
followed by giving a bill based on the chosen class, followed by the adding the hours to 
determin if the student gets financial aid or not,and then finalizing the student class awarding the
award and authorizing the student's isFullTime() or not.
*/


 


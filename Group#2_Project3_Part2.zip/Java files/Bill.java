/*Bill Class by Enrique Penaloza.
This class gets the number of hours, based on the course, from the schedule class.
To get the total, the method uses three components to add the tuition total: 
total, courseCost (later changed to partialCost),and facilityFee.
CourseCost focuses on the first 12 hours in the course schedule. This is done by using an if loop to indicate
the first 12 hours need to use this portion of the method. If the course is within the first 12 hours,
it uses parameters to indicate how much does the course cost based on whether it is an undergraduate course or 
graduate course, if it is online or not, and does the course have a lab component or not.  
The cost of the course adds up within the courseCost variable to add on the other compoonents later.
When the hours of the course schedule are over 12 hours, only online courses are charged with a fee while
campus courses are free. If the course has a paramter with a true boolean equal to the online component, then
the charge of the course adds in towards the total variable.
The facility fee is only added if the student ever has a campus course. While the course schedule searches
addes all its used array components, if it ever adds a campus course, the variable of campus count and if 
campusCount is ever equal to 1, then it will add a one time facility fee (295) to the facilityFee variable.
Once we have added all three variables, all three components add together to get a total. That total becomes a
variable to convert it to a return variable named getTuition(). 

For each hour, the credit hour is added based on the requirements stated from the stakeholder: 
$250 per undergraduate credit hour until 12 hours; after 12 hours no more charge 
$350 per graduate credit hour until 12 hours; after 12 hours no more charge
Online classes recieve a 20% premium charge; regarless hour>12 there is still a charge
If class has a lab, charge $150
$295 facility fee unless the student is only taking online classes.
*/
import java.util.*;
   
public class Bill extends Schedule {     //start of class: Bill using the schedule class
   
   float getTuition = 0f;           //the return variable
   int courseCount = 0;             //the count of courses added
   int campusCount = 0;             //counter to detect a facility fee if the user adds a != labComponent
   int number = 0;                  //class number of the course's number
   boolean labComponent = false;    //inital setting for a lab component to be later compared
   boolean isOnline = false;        //inital setting for a online course to be later tested
   float graduateCourse = 350.00f;  //the fee of a graduate course
   float labFee = 150.00f;          //the fee of a course with a lab component
   float graduateOnlineFee = 70f;   //the premium fee of a online graduate coures.
   float undergraduateCourse = 250.00f; //the fee of a undergraduate course
   float undergraduateOnlineFee = 50f;  //the premium fee of an online course for a undergraduate level
   float facilityFee = 0f;          //inital value for the facility fee
   float total = 0f;                //the inital value for the total based after 12 hours
   float totalBill = 0f;            //the inital value for the tuition total for tuition
   float courseCost = 0f;           //the inital value for the total based before 12 hours


   public Schedule schedule;
   
   public Bill(){
	   
   }
   
   public Bill(Schedule schedule){   //constructor    *Fixed error and corrected from Bill(int schedule)
   this.schedule = schedule;                         //*fixed int.schedule to this.schedule
   }
   
   public float getTuitionCost(){      //method to calculate tuition
	   courseCount = schedule.used;    // Number of courses
	   System.out.println("used: " + schedule.used);      //pulling out the array infromation nodes that are used
      for(int i = 0; i <= schedule.used - 1 ; i++ ) // if all classes are on campus or not
      {
    	  if(schedule.myList[i].isOnline() == false) //if the method ever adds a course that isn't online,
    	  {                                          //the function turns campusCount into 1 to later compare to add the facility fee towards the end.
    	       campusCount = 1; 
    	   }
    	  else
    	  {
    		  campusCount = 0;                        //no change so no fee if campusCount stays at 0;
    	  }
      } // end of for loop
      System.out.println("campuscount: " + campusCount);
         if(schedule.getHours() <= 12) //classes billed within the first 12 hours.
         {          
            for(int j = 0; j <= schedule.used-1; j++) // Goes through the courses in the schedule
            {
            	if(schedule.myList[j].number <= 4999 && ( schedule.myList[j].isLabComponent() == true) && (schedule.myList[j].isOnline() == true)){ // compares number/lab/online components of course at index
                    courseCost += undergraduateCourse + labFee+ undergraduateOnlineFee;
                 }   
                 else if (schedule.myList[j].number<=4999 && schedule.myList[j].isLabComponent()){
                    courseCost += undergraduateCourse + labFee;
                 }
                 else if (schedule.myList[j].number<=4999 && schedule.myList[j].isOnline()){
                    courseCost += undergraduateCourse + undergraduateOnlineFee;
                 }
                 else if (schedule.myList[j].number<=4999){
                    courseCost += undergraduateCourse;
                 }
                 else if(schedule.myList[j].number>=5000 && schedule.myList[j].isLabComponent() && schedule.myList[j].isOnline()){
                    courseCost += graduateCourse + labFee+ graduateOnlineFee;
                 }   
                 else if (schedule.myList[j].number>=5000 && schedule.myList[j].isLabComponent()){
                    courseCost += graduateCourse + labFee;
                 }
                 else if (schedule.myList[j].number>=5000 && schedule.myList[j].isOnline()){
                    courseCost += graduateCourse + graduateOnlineFee;
                 }
                 else
                 {
                    courseCost += graduateCourse;
                 }
               
             } // end of for loop
         } // end of bill with less than 12 hours
         else           //after the 12 hours of tuition are added, any courses remaining to be totaled are to use this else function.
         {
            for(int k = 0; k <= schedule.used - 1; k++)  //a bookkeeping method to test all the array nodes until there are no more used nodes.
            {
            	if(schedule.myList[k].number<=4999 && schedule.myList[k].isLabComponent() && schedule.myList[k].isOnline()){     //only online courses are charged after the first 12 courses
                    total += undergraduateCourse + labFee+ undergraduateOnlineFee;
                 }
                else if (schedule.myList[k].number<=4999 && schedule.myList[k].isOnline()){
                    total += undergraduateCourse + undergraduateOnlineFee;
                 }
                else if(schedule.myList[k].number>=5000 && schedule.myList[k].isLabComponent() && schedule.myList[k].isOnline()){
                  total += graduateCourse + labFee+ graduateOnlineFee;
                }
                else if (schedule.myList[k].number>=5000 && schedule.myList[k].isOnline()){
                   total += graduateCourse + graduateOnlineFee;
                }
                else
                {      //only campus courses will not be charged after the 12 courses chosen. 
                 total += 0;
                }
            } // end of for loop

         } // end of bill with more than 12 hours
         partialBill = courseCost;

      
        if( campusCount == 1 )
        {        //determining if the student has a campus course so it can charge
            facilityFee = 295;       //the student the facility fee. 
        }
        else
        {
            facilityFee = 0;         //if all were online, there is no facility fee
        }
            

        totalBill = total+ partialBill+facilityFee;     //adding all parts so it can return the bill value at the end of the foor loop.
        System.out.println("partial: " + partialBill);
        System.out.println("fee: " + facilityFee);
        System.out.println("total: " + total);
        getTuition = totalBill;     //Adds the totalBill to getTuition(which was initialized to 0)
      
        return getTuition;           //Returns the totalBill of the program.

   }  //end of getTuition() method.    
   
  
}  //end bill class   
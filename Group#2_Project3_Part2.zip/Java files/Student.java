
//Bassey_Okwong

public class Student extends FinancialAid{
	public String fName;
	public String lName;
	public int ID;
	public StudentType undergraduate;
	public StudentType graduate;
	enum StudentType{undergraduate, graduate}
	StudentType classification = undergraduate;
	public FinancialAid award;
	
	Schedule schedule = new Schedule();

	
	public Student(String fName, String lName, int ID, StudentType classification, 
			FinancialAid award){

		this.fName = fName;
		this.lName = lName;
		this.ID = ID;
		this.classification = classification;
		this.award = award;
	}
	
	public String getFirstName(){
		return fName;
	}
	
    public String getLastName(){
		return lName;
	}
	
	public String getName(){
		return (fName + " " + lName);
	}
	
	public int getID(){
		return ID;
	}
	
	public StudentType getStudentType(){
		return classification;
	}
	
	public Schedule getSchedule(){
		return schedule;
	}
	
	public boolean isFullTime(){
		
		boolean fullTime;
		if ( (getStudentType() == StudentType.graduate) && (getHours() >= 9) )
		{
			fullTime = true;
		}
		else if ( (getStudentType() == StudentType.undergraduate) && (getHours() >= 12) )
		{
			fullTime = true;
		}
		else
		{
			fullTime = false;
		}
		return fullTime;
	}
	
	public FinancialAid getAward(){
		return award;
	}
	
	public float amountDue(){
		return (getTuitionCost() - getAmount()); 
	}
}

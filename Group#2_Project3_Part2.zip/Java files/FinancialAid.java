//Bassey_Okwong
class MyOwnException extends Exception {
   public MyOwnException(String msg){
      super(msg);
   }
}

public class FinancialAid extends Bill{
	public float amount;
	public boolean enrollmentContingent;
	
	public FinancialAid(){
		
	}
	
	public FinancialAid(float amount, boolean enrollmentContingent) throws MyOwnException{
		if(amount < 0)
		{
			throw new MyOwnException("Can not have a negative amount of Financial aid.");
		}
		this.amount = amount;
		this.enrollmentContingent = enrollmentContingent;
	}
	
	public float getAmount(){
		return amount;
	}
	
	public boolean isContingent(){
		return enrollmentContingent;
		
	}

}

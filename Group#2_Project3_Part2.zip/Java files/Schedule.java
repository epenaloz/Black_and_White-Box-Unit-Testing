// Bassey_Okwong

class MyOwnException extends Exception {
   public MyOwnException(String msg){
      super(msg);
   }
}

public class Schedule extends Course{
	
	float hours = 0f;
	Course[] myList = new Course[18];
	int used = 0;
	
	public Schedule(){
		
	}
	
	
	private boolean contains(Object object){ //checks if object is in array
		
		for(int i = 0; i < used; i++)
		{
			if(myList[i] == object)
				return true;	
		}
		return false;
	}
	

	public float addCourse(Course course) throws MyOwnException{
		if(hours > 18)
		{
			throw new MyOwnException("Can not have a schedule with more than 18 hours.");
		}
		else if(contains(course)) // if course is already in the schedule
		{
			System.out.println("The course " + course.getCourseName() + course.getCourseNumber() +
					" " + "is already in the schedule.");
		}
		else //hours not > 18 and course not in schedule
		{
			for(int i = 0; i <= used; i++)
			{
				if (myList[i] == null)
				{
					myList[i] = course;
				}
			}
			hours += course.getHours();
			used++;

		}
		return hours;
	}
	
	public float removeCourse(Course course){
		assert(contains(course)); //assert course is in schedule
		for(int k = 0; k < myList.length; k++) // find the course and removes it
		{
			if(myList[k] == course)
			{
				myList[k] = myList[k+1];
			}
			
		}
		used--;
		hours -= course.getHours();
		if(!contains(course)) // if course not in schedule
		{
			System.out.println("Course " + course.getCourseName() + course.getCourseNumber() + 
			" is not in the schedule." );
		}
		return hours;	
	}
	
	public float getHours(){
		return hours;
	}
	
	public Course[] getCourses(){
		
		return myList;
	}
	
	public void clearSchedule(){
		hours = 0;
		for(int i = 0; i <= used; i++)
		{
			myList[i] = null;
		}
	}
	
	
	
}
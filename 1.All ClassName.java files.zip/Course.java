class MyOwnException extends Exception {
   public MyOwnException(String msg){
      super(msg);
   }
}

public class Course  {
	public String name;
	public String prefix;
	public int number;
	public int section;
	public float hours;
	public boolean online;
	public boolean labComponent;
	
	public Course(){
		
	}
	
	public Course(String name, String prefix, int number, int section, float hours, boolean online,
			boolean labComponent) throws MyOwnException{
			if(hours < 0)
			{
				throw new MyOwnException("Hours can not be negative.");
			}
			else if (number  < 1101) 
			{
				throw new MyOwnException("Number can not be less than 1101.");
			}
			
			else if(section < 1)
			{
				throw new MyOwnException("Section can not be less than 1");
			}
		this.name = name;
		this.prefix = prefix;
		this.number = number;
		this.section = section;
		this.hours = hours;
		this.online = online;
		this.labComponent = labComponent;
	}
	
	public String getCourseName(){
		return name;
	}
	
	public String getCourseNumber(){
		return (prefix + " " + number + " " + section);
	}
	
	public float getHours(){
		return hours;
	}
	
	public boolean isOnline(){
		return online;
	}
	
	public boolean isLabComponent(){
		return labComponent;
	}
	

}

//Bassey_Okwong

public class Student extends FinancialAid_stub{
()	public String fName;
	public String lName;
	public int ID;
	public StudentType undergraduate;
	public StudentType graduate;
	enum StudentType{undergraduate, graduate}
	StudentType classification = undergraduate;
	public FinancialAid_stub award;
	
	
	
	public Student(String fName, String lName, int ID, StudentType classification, 
			FinancialAid_stub award){

		this.fName = fName;
		this.lName = lName;
		this.ID = ID;
		this.classification = classification;
		this.award = award;
	}
	
	public String getFirstName(){
		return fName;
	}
	
    public String getLastName(){
		return lName;
	}
	
	public String getName(){
		return (fName + " " + lName);
	}
	
	public int getID(){
		return ID;
	}
	
	public StudentType getStudentType(){
		return classification;
	}
	
	public boolean isFullTime(){
		
		boolean fullTime;
		if ( (getStudentType() == StudentType.graduate) && (getHours() >= 9) )
		{
			fullTime = true;
		}
		else if ( (getStudentType() == StudentType.undergraduate) && (getHours() >= 12) )
		{
			fullTime = true;
		}
		else
		{
			fullTime = false;
		}
		return fullTime;
	}
	
	public FinancialAid_stub getAward(){
		return award;
	}
	
	public Schedule_stub getSchedule(){
		return getCourses();
	}
	
	public float amountDue(){
		return (getTuitionCost() - getAmount()); 
	}
}


public class FinancialAid extends Bill {
	public float amount;
	public boolean enrollmentContingent;
	
	public FinancialAid(){
		
	}
	
	public FinancialAid(float amount, boolean enrollmentContingent){
		this.amount = amount;
		this.enrollmentContingent = enrollmentContingent;
	}
	
	public float getAmount(){
		return amount;
	}
	
	public boolean isContingent(){
		if (enrollmentContingent)
		{
			return true;
		}
		
		else
		{
			return false;
		}
	}

}

public class Schedule extends Course{
	

	public Schedule(){
		
	}

	public float addCourse(Course course){
		return course.getHours();
	}
	
	public float removeCourse(Course course){
		return course.getHours();		
	}
	
	public float getHours(){
	return 1;
	}
	
	public String getCourses(){
	return null;
	}
	
	public void clearSchedule(){
	
	}
}
public class Driver{
public static void main(String[] args)
{
  Student bob = new Student(“Bob”,”Smith”,12345,Student.StudentType.undergraduate, new FinancialAid(5000, true));
  Student joe = new Student(“Joseph”,”Jones”,987654,Student.StudentType.graduate, new FinancialAid(2000, false));
  Student[] myStudents = { bob, joe };

  // Add some courses to the schedule of both bob and joe here.
  // The syntax to do this would be of the form:
     bob.getSchedule().addCourse(new Course("Software Testing", "SWE", 3643, 3, 3.0, true, true) );
     bob.getSchedule().addCourse(new Course("Software Enginerring", "SWE", 4435, 4, 3.0, true, false) );
     bob.getSchedule().addCourse(new Course("Software Architecture", "SWE", 4262, 4, 3.0, false, true) );
     bob.getSchedule().addCourse(new Course("Software Development", "SWE", 3854, 3, 3.0, false, false) );
     joe.getSchedule().addCourse(new Course("Cloud computing", "CS", 4512, 3, 3.0, true, true) );
     joe.getSchedule().addCourse(new Course("Data Mining", "CS", 5743, 3, 3.0, true, false) );
     joe.getSchedule().addCourse(new Course("Computer principles 2", "CS", 3143, 4, 3.0, false, true) );
     joe.getSchedule().addCourse(new Course("Data Structures", "CS", 5001, 4, 3.0, false, false) );

  //bob.getSchedule().addCourse(new Course("Software Testing", "SWE", 3643, 1, 3.0, false, false) );
  // Be sure to choose a suitable variety and number of courses.

  // You might consider removing a course or two here to make sure that works as well.

  for (Student s : myStudents)
  {
    System.out.print( s.getFirstName + “ “ + s.getLastName + “ is “);

    if (s.getStudentType == Student.StudentType.undergraduate)
      System.out.print(“an undergraduate ”);
    else
      System.out.print(“a graduate ”);

    System.out.println(“student with ID #” + s.getID() + “.”);
    System.out.print(“The student is enrolled for “ + s.getSchedule().getHours() + “ hours and is classified as “);

    if (s.isFullTime())
      System.out.println(“ full-time.”);
    else 
      System.out.println(“ part-time.”); 

    System.out.print(“The student’s financial aid award is $“ + s.getAward().getAmount() + ” and is “);

    if ( ! s.getAward().isContingent() )
      System.out.print(“NOT “);

    System.out.println(“contingent on full-time enrollment.”);
    System.out.println(“The student’s tuition bill is $” + s.amountDue() + “.”);
    System.out.print("\n\n");
  }
}}
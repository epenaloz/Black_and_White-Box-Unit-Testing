/*Tester/Student: Enrique Penaloza. Group Member: Okwong Bassey (Refered to Skip)
Testing Student class
//explaining the black box texting approach or approaches you have 
employed and why do you think is appropriate.
I created a decision table to help me test the student class from my fellow group member using the 
blackbox method. The types of methods I used to test this class is Boundary Value Testing and
Weak Robust Equivalence testing. Using both methods, Using these two methods, I focused on the number of hours
the student would have in his schedule because that would decide if he would get the FinancialAid award,
be declaed as a FullTime student or not, and return a NULL schedule, a negative schedule, or a valid schedule.
I didn't test the string methods because anything I would type would display it as a name. The student type
is the main determinination on which StudentType I would test the different hours based upon.
For an undergraduate, its fullTime is hours>=12, while the graduate's fullTime meter is hours>=9. Anything
over 18 hours for both of them would result in an error, but would still display the student's first and
last name, if given.

My staic void main would give me this error message:

main.cpp:17:1: error: 
       expected
       unqualified-id
 pu... 
*/

public class Student_BlackBoxTest{
   public static void main(String[] args){
      String fName = "Ash", lName = "Ketchum";
      int ID = 56485;
      boolean undergraduate = true; // "undergraduate", false: graduate = "graduate";
      int hours; //hours to be determined to return a fullTime student or not.
      boolean award= true; //Needs fullStudent to be true to award the student financial Aid.
      
      System.out.println(fName+lName+" "+ID+" "+undergraduate+" "+hours+" "+award); 
            }     
} 
 
class Student_BlackBoxTest{   

      public boolean undergradute(){
      if (hours>=12){
         return true;
         }
         else{
            return false;
         }
       public boolean gradute(){
         if (hours>=9){
         return true;
         }
         else{
            return false;
         }
         }
      
         
      Student case1 = new Student(fName, lName, 56789, undergraduate, award);
      hours = 0;
      system.out.println(case1);
      /*The amount of course hours will not give an awade based on the StudentType not being a fullTime student,
      but it will still pass because the array of classs will be zero or Null created by the constructor method.
      The fName, lName, ID,undergraduate (because everything is valid), and award the student a bill of $0. 
      My code will fail the system, but theorteically it should pass the preequirements.     
      */
      Student case2 = new Student(fNale, lName, 56789, undergraduate, award);
      hours = 8;
      System.out.println(case2);
      /*The amount of course hours will not give an awade based on the StudentType not being a fullTime student,
      but it will still pass because the array of classs will have eight courses in the course file.
      The fName, lName, ID,undergraduate (because everything is valid), and award the student a bill with no 
      financial aid award to subtract. 
      My code will fail the system, but theorteically it should pass the preequirements and return the 
      student's parameters.     
      */
      Student case3 = new Student(fName, lName, 56789, undergraduate, award);
      hours = 9;
      System.out.println(case3);
      /*The amount of course hours will not give an awade based on the StudentType not being a fullTime student,
      but it will still pass because the array of classs will have nine courses in the course file.
      The fName, lName, ID,undergraduate (because everything is valid), and award the student a bill with no 
      financial aid award to subtract. 
      My code will fail the system, but theorteically it should pass the preequirements and return the 
      student's parameters.     
      */
      Student case4 = new Student(fName, lName, 56789, undergraduate, award);
      hours = 10;
      system.out.println(case4);   
      /*The amount of course hours will not give an awade based on the StudentType not being a fullTime student,
      but it will still pass because the array of classs will have ten courses in the course file.
      The fName, lName, ID,undergraduate (because everything is valid), and award the student a bill with no 
      financial aid award to subtract. 
      My code will fail the system, but theorteically it should pass the preequirements and return the 
      student's parameters.     
      */      
      Student case5 = new Student(fNale, lName, 56789, undergraduate, award);
      hours = 12;
      System.out.println(case5);
      /*The amount of course hours will give an awade based on the StudentType being a fullTime student. 
      With the prerequirement having the undergraduate have 12 hourses, it triggers the financial aid award
      and returns the amoundDue() with the bill minus the finanical aid award. 
      My code will fail the system, but theorteically it should pass the preequirements and have the student class
      return all of the parameters 
      of Student(String fName, StringlName, int ID, Classification classification, FinanicalAid award).     
      */
      
      Student case6 = new Student(fName, lName, 56789, undergraduate, award);
      hours = 18;
      System.out.println(case6);
      /*The amount of course hours will give an awade based on the StudentType being a fullTime student. 
      With the prerequirement having the undergraduate have 18 hourses, but fewer than 19, 
      it triggers the financial aid award and returns the amoundDue() with the bill minus the finanical aid award. 
      My code will fail the system, but theorteically it should pass the preequirements and have the student class
      return all of the parameters 
      of Student(String fName, StringlName, int ID, Classification classification, FinanicalAid award).     
      */
      
      Student case7 = new Student(fName, lName, 56789, undergraduate, award);
      hours = 19;
      system.out.println(case7);   
      /*The amount of course hours will not give an awade but an error message
      based on the schedule class's paramter of a student not having more than 18 courses.
      My code will fail the system, but theorteically it shouldn't pass the preequirements and return the 
      an error with an exception message.     
      */
      Student case8 = new Student(fNale, lName, 56789, undergraduate, award);
      hours = -1;
      System.out.println(case8);
      /*The amount of course hours will not give an awade but an error message
      based on the student class's paramter of a student not having less than 0 courses to get an amount due.
      My code will fail the system, but theorteically it shouldn't pass the preequirements and return the 
      an error with an exception message.     
      */      
      Student case9 = new Student(fName, lName, 56789, graduate, award);
      hours = 0;
      system.out.println(case9);   
      /*The amount of course hours will not give an awade based on the StudentType not being a fullTime student,
      but it will still pass because the array of classs will be zero or Null created by the constructor method.
      The fName, lName, ID,undergraduate (because everything is valid), and award the student a bill of $0. 
      My code will fail the system, but theorteically it should pass the preequirements and return the Student class.     
      */
   
      Student case10 = new Student(fNale, lName, 56789, graduate, award);
      hours = 8;
      System.out.println(case10);
      /*The amount of course hours will not give an awade based on the StudentType not being a fullTime student,
      but it will still pass because the array of classs will have eight courses in the course file.
      The fName, lName, ID,undergraduate (because everything is valid), and award the student a bill with no 
      financial aid award to subtract. 
      My code will fail the system, but theorteically it should pass the preequirements and return the 
      student's parameters.
      */      
      Student case11 = new Student(fName, lName, 56789, graduate, award);
      hours = 9;
      System.out.println(case11);
      /*The amount of course hours will give an awade based on the StudentType being a fullTime student. 
      With the prerequirement having the graduate have 9 hourses, it triggers the financial aid award
      and returns the amoundDue() with the bill minus the finanical aid award. 
      My code will fail the system, but theorteically it should pass the preequirements and have the student class
      return all of the parameters 
      of Student(String fName, StringlName, int ID, Classification classification, FinanicalAid award).     
      */
      
      Student case12 = new Student(fName, lName, 56789, graduate, award);
      hours = 10;
      system.out.println(case12);   
      /*The amount of course hours will give an awade based on the StudentType being a fullTime student. 
      With the prerequirement having the graduate have 10 hourses, it triggers the financial aid award
      and returns the amoundDue() with the bill minus the finanical aid award. 
      My code will fail the system, but theorteically it should pass the preequirements and have the student class
      return all of the parameters 
      of Student(String fName, StringlName, int ID, Classification classification, FinanicalAid award).     
      */      
      
      Student case13 = new Student(fNale, lName, 56789, graduate, award);
      hours = 12;
      System.out.println(case13);
      /*The amount of course hours will give an awade based on the StudentType being a fullTime student. 
      With the prerequirement having the graduate have 12 hourses, it triggers the financial aid award
      and returns the amoundDue() with the bill minus the finanical aid award. 
      My code will fail the system, but theorteically it should pass the preequirements and have the student class
      return all of the parameters 
      of Student(String fName, StringlName, int ID, Classification classification, FinanicalAid award).     
      */
      
      Student case14 = new Student(fName, lName, 56789, graduate, award);
      hours = 18;
      System.out.println(case14);
      /*The amount of course hours will give an awade based on the StudentType being a fullTime student. 
      With the prerequirement having the graduate have 18 hourses, but fewer than 19, 
      it triggers the financial aid award and returns the amoundDue() with the bill minus the finanical aid award. 
      My code will fail the system, but theorteically it should pass the preequirements and have the student class
      return all of the parameters 
      of Student(String fName, StringlName, int ID, Classification classification, FinanicalAid award).     
      */
       
      Student case15 = new Student(fName, lName, 56789, graduate, award);
      hours = 19;
      system.out.println(case15);   
      /*The amount of course hours will not give an awade but an error message
      based on the schedule class's paramter of a student not having more than 18 courses.
      My code will fail the system, but theorteically it shouldn't pass the preequirements and return the 
      an error with an exception message.     
      */      
      Student case16 = new Student(fNale, lName, 56789, graduate, award);
      hours = -1;
      System.out.println(case16);
      /*The amount of course hours will not give an awade but an error message
      based on the student class's paramter of a student not having less than 0 courses to get an amount due.
      My code will fail the system, but theorteically it shouldn't pass the preequirements and return the 
      an error with an exception message.     
      */
      }      
      
            
                 
      
}
}
// Okwong Bassey

	/*        In this testing I have done weak robust testing. I think this is appropriate
			 * because I have tested Courses both undergraduate and graduate. I have tested
			 * both types of courses with whole number credit hours and half credit hours.
			 * I have made schedules with negative course hours, zero course hours,
			 * and course hours ranging from 1 to 12 which was the range of course hours
			 * with charges. I have also tested schedules in both types with 13 hours
			 * to see if not charges apply.                                                 */
public class Bill_BlackBoxTest {

	public static void main(String[] args)throws MyOwnException {
		
		Course c1 = new Course("Software Systems requirements", "SWE",
				3623, 01, 3.5f, true, true);
		
		Course c2 = new Course("User Centered Design", "SWE", 4324, 01, 4f,	
				true, false);
		
		Course c3 = new Course("Operating Systems" , "CS", 3502, 03, 2.5f,
				false, true);
		
		Course c4 = new Course("Software Project Managment", "SWE", 4663, 01, 3f,
				false, false);
		
		Course c5 = new Course("Physical Education", "PE", 1101, 2, 2f, false, false);
		
		Course c6 = new Course("Communications", "COMM", 1101, 1, 1f, false, false);
		
		Course c7 = new Course("Servant Leadership", "PHED", 1201, 1, 0f, false, true);
		
		Course c8 = new Course("Leadership Development" , "PHED", 1202, 5, .5f, true, false);
		
		
		Course c10 = new Course("Professional Ethics", "ETH", 1301, 1, 3f, true, true);
		
		Course c11 = new Course(" Grad 1", "SWE", 5001, 2, 0f, true, true);
		
		Course c12 = new Course("Grad 2", "SWE", 5410, 1, .5f, true, false);
		
		Course c13 = new Course("Grad 3", "SWE", 5110, 1, 1f, false, false);
		
		Course c14 = new Course("Grad 4", "SWE", 5113, 2, 1.5f, false, true);
		
		Course c15 = new Course("Grad 5", "SWE", 5210, 1, 2f, true, false);

		Course c16 = new Course("Grad 6", "SWE", 5110, 1, 2.5f, true, false);
		
		Course c17 = new Course("Grad 7", "SWE", 6110, 1, 3f, true, false);
		
		Course c18 = new Course("Grad 8", "SWE", 6210, 1, 3.5f, true, false);
		
		Course c19 = new Course("Grad 9", "SWE", 7110, 1, 4f, true, false);
		
		Course c20 = new Course("Grad 10", "SWE", 5213, 1, 3f, false, false);
		
		Course c21 = new Course("undergrad", "SWE", 4562, 2, .5f, true, false);
		
        Schedule_stub s1 = new Schedule_stub();

		
		//Bill with no hours(undergrad)
		Bill b1 = new Bill(s1);
		System.out.println("Bill with no hours(undergrad) ");
		System.out.println("Bill: " + b1.getTuitionCost());
		
		System.out.println("\n");
		
		//Bill with negative hours(undergrad)
		//s1.addCourse(c9); // -1
		System.out.println("Bill with negative(undergrad) ");
		Bill b2 = new Bill(s1);
		System.out.println("Bill: " + b2.getTuitionCost());
		
		System.out.println("\n");
		s1.clearSchedule();

		//Bill with .5 hours(undergrad)
		s1.addCourse(c8); // .5
		System.out.println("Bill with .5 hours(undergrad) ");
		Bill b3 = new Bill(s1);
		System.out.println("Bill: " + b3.getTuitionCost());
		
		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 1 hour(undergrad)
		s1.addCourse(c6); //1
		System.out.println("Bill with 1 hours(undergrad) ");
		Bill b4 = new Bill(s1);
		System.out.println("Bill: " + b4.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();

		//Bill with 1.5 hours(undergrad)
		s1.addCourse(c6); //1
		s1.addCourse(c8); //.5
		System.out.println("Bill with 1.5 hours(undergrad) ");
		Bill b5 = new Bill(s1);
		System.out.println("Bill: " + b5.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 2 hours(undergrad)
		s1.addCourse(c5); //2
		System.out.println("Bill with 2 hours(undergrad) ");
		Bill b6 = new Bill(s1);
		System.out.println("Bill: " + b6.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 2.5 hours(undergrad)
		s1.addCourse(c5); //2
		s1.addCourse(c8); //.5
		System.out.println("Bill with 2.5 hours(undergrad) ");
		Bill b7 = new Bill(s1);
		System.out.println("Bill: " + b7.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 3 hours(undergrad)
		s1.addCourse(c4); //3
		System.out.println("Bill with 3 hours(undergrad) ");
		Bill b8 = new Bill(s1);
		System.out.println("Bill: " + b8.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 3.5 hours(undergrad)
		s1.addCourse(c4);//3
		s1.addCourse(c8);//.5
		System.out.println("Bill with 3.5 hours(undergrad) ");
		Bill b9 = new Bill(s1);
		System.out.println("Bill: " + b9.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 4 hours(undergrad)
		s1.addCourse(c2);//4
		System.out.println("Bill with 4 hours(undergrad) ");
		Bill b10 = new Bill(s1);
		System.out.println("Bill: " + b10.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 4.5 hours(undergrad)
		s1.addCourse(c2);//4
		s1.addCourse(c8);//.5
		System.out.println("Bill with 4.5 hours(undergrad) ");
		Bill b11 = new Bill(s1);
		System.out.println("Bill: " + b11.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 5 hours(undergrad)
		s1.addCourse(c2);//4
		s1.addCourse(c6);//1
		System.out.println("Bill with 5 hours(undergrad) ");
		Bill b12 = new Bill(s1);
		System.out.println("Bill: " + b12.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 5.5hours(undergrad)
		s1.addCourse(c2);//4
		s1.addCourse(c6);//1
		s1.addCourse(c8);//.5
		System.out.println("Bill with 5.5 hours(undergrad) ");
		Bill b13 = new Bill(s1);
		System.out.println("Bill: " + b13.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 6 hours(undergrad)
		s1.addCourse(c4);//3
		s1.addCourse(c10);//3
		System.out.println("Bill with 6 hours(undergrad) ");
		Bill b14 = new Bill(s1);
		System.out.println("Bill: " + b14.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 6.5 hours(undergrad)
		s1.addCourse(c4);//3
		s1.addCourse(c10);//3
		s1.addCourse(c8);//.5
		System.out.println("Bill with 6.5 hours(undergrad) ");
		Bill b15 = new Bill(s1);
		System.out.println("Bill: " + b15.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 7 hours(undergrad)
		s1.addCourse(c2);//4
		s1.addCourse(c4);//3
		Bill b16 = new Bill(s1);
		System.out.println("Bill with 7 hours(undergrad) ");
		System.out.println("Bill: " + b16.getTuitionCost());
		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 7.5 hours(undergrad)
		s1.addCourse(c2);//4
		s1.addCourse(c4);//3
		s1.addCourse(c8);//.5
		System.out.println("Bill with 7.5 hours(undergrad) ");
		Bill b17 = new Bill(s1);
		System.out.println("Bill: " + b17.getTuitionCost());
		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 8 hours(undergrad)
		s1.addCourse(c2);//4
		s1.addCourse(c4);//3
		s1.addCourse(c6);//1
		System.out.println("Bill with 8 hours(undergrad) ");
		Bill b18 = new Bill(s1);
		System.out.println("Bill: " + b18.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 9 hours(undergrad)
		s1.addCourse(c2);//4
		s1.addCourse(c4);//3
		s1.addCourse(c5);//2
		System.out.println("Bill with 9 hours(undergrad) ");
		Bill b19 = new Bill(s1);
		System.out.println("Bill: " + b19.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 10 hours(undergrad)
		s1.addCourse(c2);//4
		s1.addCourse(c4);//3
		s1.addCourse(c5);//2
		s1.addCourse(c6);//1
		System.out.println("Bill with 10 hours(undergrad) ");
		Bill b20 = new Bill(s1);
		System.out.println("Bill: " + b20.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 12 hours(undergrad)
		s1.addCourse(c2);//4
		s1.addCourse(c4);//3
		s1.addCourse(c5);//2
		s1.addCourse(c3);//2.5
		s1.addCourse(c8);//.5
		System.out.println("Bill with 12 hours(undergrad) ");
		Bill b21 = new Bill(s1);
		System.out.println("Bill: " + b21.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 13 hours(undergrad)
		s1.addCourse(c2);//4
		s1.addCourse(c4);//3
		s1.addCourse(c5);//2
		s1.addCourse(c3);//2.5
		s1.addCourse(c8);//.5
		s1.addCourse(c6);//1
		System.out.println("Bill with 13 hours(undergrad) ");
		Bill b22 = new Bill(s1);
		System.out.println("Bill: " + b22.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 0 hours(grad)
		s1.addCourse(c11);
		System.out.println("Bill with no hours(grad) ");
		Bill b23 = new Bill(s1);
		System.out.println("Bill: " + b23.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with .5 hours(grad)
		s1.addCourse(c12);//.5
		System.out.println("Bill with .5 hours(grad) ");
		Bill b24 = new Bill(s1);
		System.out.println("Bill: " + b24.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 1 hour(grad)
		s1.addCourse(c13);//1
		System.out.println("Bill with 1 hours(grad) ");
		Bill b25 = new Bill(s1);
		System.out.println("Bill: " + b25.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 1.5 hour(grad)
		s1.addCourse(c14);//1.5
		System.out.println("Bill with 1.5 hours(grad) ");
		Bill b26 = new Bill(s1);
		System.out.println("Bill: " + b26.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 2 hours(grad)
		s1.addCourse(c15);//2
		System.out.println("Bill with 2 hours(grad) ");

		Bill b27 = new Bill(s1);
		System.out.println("Bill: " + b27.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 2.5 hours(grad)
		s1.addCourse(c16);//2.5
		System.out.println("Bill with 2.5 hours(grad) ");
		Bill b28 = new Bill(s1);
		System.out.println("Bill: " + b28.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 3 hours(grad)
		s1.addCourse(c17);//3
		System.out.println("Bill with 3 hours(grad) ");
		Bill b29 = new Bill(s1);
		System.out.println("Bill: " + b29.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 3.5 hours(grad)
		s1.addCourse(c18);//3.5
		System.out.println("Bill with 3.5 hours(grad) ");
		Bill b30 = new Bill(s1);
		System.out.println("Bill: " + b30.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 4 hours(grad)
		s1.addCourse(c19);//4
		System.out.println("Bill with 4 hours(grad) ");
		Bill b31 = new Bill(s1);
		System.out.println("Bill: " + b31.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 4.5 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c12);//.5
		System.out.println("Bill with 4.5 hours(grad) ");
		Bill b32 = new Bill(s1);
		System.out.println("Bill: " + b32.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 5 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c13);//1
		System.out.println("Bill with 5 hours(grad) ");
		Bill b33 = new Bill(s1);
		System.out.println("Bill: " + b33.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 5.5 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c13);//1
		s1.addCourse(c12);//.5
		Bill b34 = new Bill(s1);
		System.out.println("Bill with 5.5 hours(grad) ");
		System.out.println("Bill: " + b34.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 6 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c15);//2
		Bill b35 = new Bill(s1);
		System.out.println("Bill with 6 hours(grad) ");
		System.out.println("Bill: " + b35.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 6.5 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c16);//2.5
		Bill b36 = new Bill(s1);
		System.out.println("Bill with 6.5 hours(grad) ");
		System.out.println("Bill: " + b36.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 7 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c17);//3
		Bill b37 = new Bill(s1);
		System.out.println("Bill with 7 hours(grad) ");
		System.out.println("Bill: " + b37.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 7.5 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c18);//3.5
		Bill b38 = new Bill(s1);
		System.out.println("Bill with 7.5 hours(grad) ");
		System.out.println("Bill: " + b38.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 8 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c18);//3.5
		s1.addCourse(c21);//.5
		Bill b39 = new Bill(s1);
		System.out.println("Bill with 8 hours(grad) ");
		System.out.println("Bill: " + b39.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 8.5 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c18);//3.5
		s1.addCourse(c14);//1.5
		Bill b40 = new Bill(s1);
		System.out.println("Bill with 8.5 hours(grad) ");
		System.out.println(b40.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 9 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c17);//3
		s1.addCourse(c15);//2
		Bill b41 = new Bill(s1);
		System.out.println("Bill with 9 hours(grad) ");
		System.out.println("Bill: " + b41.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 9.5 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c17);//3
		s1.addCourse(c16);//2.5
		Bill b42 = new Bill(s1);
		System.out.println("Bill with 9.5 hours(grad) ");
		System.out.println("Bill: " + b42.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 10 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c18);//3.5
		s1.addCourse(c16);//2.5
		Bill b43 = new Bill(s1);
		System.out.println("Bill with 10 hours(grad) ");
		System.out.println("Bill: " + b43.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 10.5 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c17);//3
		s1.addCourse(c16);//2.5
		s1.addCourse(c12);//.5
		Bill b44 = new Bill(s1);
		System.out.println("Bill with 10.5 hours(undergrad) ");
		System.out.println("Bill: " + b44.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 11 hours (grad)
		s1.addCourse(c19);//4
		s1.addCourse(c17);//3
		s1.addCourse(c16);//2.5
		s1.addCourse(c14);//1.5
		Bill b45 = new Bill(s1);
		System.out.println("Bill with 11 hours(grad) ");
		System.out.println("Bill: " + b45.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 11.5 hours (grad)
		s1.addCourse(c19);//4
		s1.addCourse(c17);//3
		s1.addCourse(c16);//2.5
		s1.addCourse(c14);//1.5
		s1.addCourse(c12);//.5
		Bill b46 = new Bill(s1);
		System.out.println("Bill with 11.5 hours(grad) ");
		System.out.println("Bill: " + b46.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 12 hours(grad)
		s1.addCourse(c19);//4
		s1.addCourse(c17);//3
		s1.addCourse(c16);//2.5
		s1.addCourse(c14);//1.5
		s1.addCourse(c13);//1
		Bill b47 = new Bill(s1);
		System.out.println("Bill with 12 hours(grad) ");
		System.out.println("Bill: " + b47.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
		
		//Bill with 15 hours (grad)
		s1.addCourse(c19);//4
		s1.addCourse(c17);//3
		s1.addCourse(c16);//2.5
		s1.addCourse(c14);//1.5
		s1.addCourse(c13);//1
		s1.addCourse(c20);//3
		Bill b48 = new Bill(s1);
		System.out.println("Bill with 15 hours(grad) ");
		System.out.println("Bill: " + b48.getTuitionCost());

		System.out.println("\n");
		s1.clearSchedule();
	}

}

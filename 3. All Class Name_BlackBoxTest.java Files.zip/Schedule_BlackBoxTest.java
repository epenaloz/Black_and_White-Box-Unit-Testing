/*By: Enrique Penaloza 
To test this class, I am going to perform black box testing by
using methods Weak Robust Equivalence Class Testing and
Boundary Values Testing. The boundary values of this class is the student can't
have less than 0 hours registered and more than 18 hours registered. Using the boundary values, we
will use Weak Robust Equivalence Class Testing by testing less than 0 hours registered and more
than 18 hours registered and output the test execution. 
These test cases will result in 8 test cases.
*/
class Schedule_BlackBoxTest {
   public static void main(String[] args)
   {
      


//test case 1: null array, then add one class: boundary value testing




//test case 2: null array, then remove one class: robust testing-invalid-


//test case 3: array has one course registered, remove one: boundary testing-valid-

//test case 4: mull array, addx4 courses: robust testing -valid-

//test case 5: null array, addx4 courses, remove 1-valid- testing out the remove function 


//test case 6: array has 18, removes one


//test case 7: array has 18


//test case 8: array has 18, add one --error- 
}
}

/*
OUTPUT



*/
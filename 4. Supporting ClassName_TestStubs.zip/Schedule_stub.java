
public class Schedule_stub extends Course {
	
	public Schedule_stub(){
		
	}
	
	public float addCourse(Course course){
		return 1;
	}
	
	public float removeCourse(Course course){
		return 2;
	}
	
	public void clearSchedule(){
		
	}
	
	public Course[] getCourses(){
		return null;
	}
	
	public float getHours(){
		return 4;
	}

}

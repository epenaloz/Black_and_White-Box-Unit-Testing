
public class Bill_stub extends Schedule_stub {
	
	public Bill_stub(){
		
	}
	
	public Bill_stub(Schedule_stub schedule){
		
	}
	
	public float getTuitionCost(){
		return 1;
	}

}
